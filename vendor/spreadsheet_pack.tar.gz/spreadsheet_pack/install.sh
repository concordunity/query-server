#!/bin/bash

echo "您好，现在开始进行gem包的本地安装，等待过程有些漫长。。。。"
echo "================第一个，现在开始安装ruby-ole-1.2.11.4.gem ================================="
rvm all do gem install ruby-ole-1.2.11.4.gem

echo "================第一个，现在开始安装spreadsheet-0.7.3.gem ================================="
rvm all do gem install spreadsheet-0.7.3.gem

echo "gem包安装结束。。。。。"
