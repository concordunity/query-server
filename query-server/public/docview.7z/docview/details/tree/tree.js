steal(
	'jquery/controller',
	'jquery/view/ejs',
    'jquery/controller/view',
    'jquery/dom/route',
    'jquery/lang/observe/delegate',
    'docview/models',
    
    'docview/bootstrap/bootstrap.css'
)

// View templates
.then(
    './views/init.ejs',
    './views/pages.ejs'
)

.then(function($) {

    /*
    * Tree view for a selected document
    */
    $.Controller('Docview.Details.Tree',
    /* @Static */
    {
    },
    /* @Prototype */
    {
        init: function() {
            this.element.html(this.view('init', {}));
        },
        'li a click': function(el, ev) {
            // Set page to href value without the leading '#'
            this.options.clientState.attr('document').attr('current', +(el.attr('href').substring(1)));
            ev.preventDefault();
        },
        '{clientState} document.current change': function(el, ev, attr, how, newVal, oldVal) {
            if (how === "set" || how === "add") {
                this.element.find('li').removeClass('active');
                this.element.find('.page-' + newVal).addClass('active');
            }
        },
        
        
        // Waits for data to be set in this form:
        // document: {
        //    pages: [] // Array of pages
        //    directory: "" // Location of image
        //    metadata: {} // metadata
        //    groups: [subgroup, subgroup, ...] // groups of images
        // }
        '{clientState} document change': function(el, ev, attr, how, newVal, oldVal)  {
            //console.log("[Attr]", attr);
            //console.log("[How]", how);
            //console.log("[Old]", oldVal);
            //console.log("[New]", newVal);
            
            if (attr === "document" && (how === "set" || how === "add")) {
                this.element.find('.nav').html(this.view('pages', newVal.groups));
            }
        }
    });
});
