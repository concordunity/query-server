steal(
	'jquery/controller',
	'jquery/view/ejs',
    'jquery/controller/view',
    'jquery/dom/route',
    'jquery/lang/observe/delegate',
    'docview/models',
    'docview/details/tree',
    'docview/details/viewer',
    
    'docview/bootstrap/bootstrap.css'
)

// View templates
.then(
    './views/init.ejs'
)

.then(function($) {

    /*
    * Tree view for a selected document
    */
    $.Controller('Docview.Details',
    /* @Static */
    {
    },
    /* @Prototype */
    {
        init: function() {
            this.element.html(this.view('init', {}));
            
            // By default we're hidden until the route conditions are met
            this.element.hide();

            this.element.find('#document-tree').docview_details_tree({clientState: this.options.clientState});
            this.element.find('#document-viewer').docview_details_viewer({clientState: this.options.clientState});            
        },
        '{$.route} category change': function(el, ev, attr, how, newVal, oldVal)  {
            if (newVal === "document") {
                this.element.show();
            }
            else {
                this.element.hide();
            }
        },
        '{$.route} page change': function(el, ev, attr, how, newVal, oldVal) {
            // this will have problems when you refresh the page and the event is an add and we
            // don't have the data populated yet
            this.element.find('li').removeClass('active');
            var pageSelector = '.page-' + newVal;
            this.element.find(pageSelector).addClass('active');
        },
        '{$.route} id change': function(el, ev, attr, how, newVal, oldVal) {
            // TODO: If we set category and id values sequentually, are the events done in order?
            //       i.e. does:
            //       $.route.attrs({ "category": "document", "id": "103420121342000022" }, true);
            //       yield:
            //       category change event, followed by id change event?
            if ($.route.attr('category') === 'document') {
                Docview.Models.File.findOne(newVal, this.proxy('setData'), this.proxy('failure'));
            }
        },
        setData: function(file) {
            /*document: {
                    pages: [] // Array of pages
                    directory: "" // Location of image
                    metadata: {} // metadata
                    groups: [subgroup, subgroup, ...] // groups of images
            }*/
            var metadata = file.doc_info;
            var directory = "/docimages/";
            
            var groups = new Array();
            var subgroup = new Array();
            var pages = new Array();
            var images = file.image_info.T_blog;
            var prevType;
            var prevGroupName;
            for (var i = 0; i < metadata.pages; i++) {
                if (images[i].TCode !== prevType && prevType !== undefined) {
                    // Push previous subgroup and type into groups
                    groups.push({type: prevType, name: prevGroupName, pages: subgroup});
                    subgroup = new Array();
                }
                subgroup.push(images[i].FN);
                pages.push(images[i].FN);
                
                /*if (pages[i].back !== undefined) {
                    subgroup.push(pages[i].back);
                    pageArray.push(pages[i].back);
                }*/
                prevType = images[i].TCode;
                prevGroupName = images[i].T;
            }
            // Push our remaining subgroup into groups
            groups.push({type: prevType, name: prevGroupName, pages: subgroup});
            
            console.log({
                pages: pages,
                directory: directory,
                metadata: metadata,
                groups: groups
            });
            this.options.clientState.attr('document', {
                pages: pages,
                directory: directory,
                metadata: metadata,
                groups: groups
            });
            
            // Start at page 1 by default
            this.options.clientState.attr('document').attr('current', 1);
        },
        failure: function(data) {
            console.log("[Error]", data);
        },
    });
});
