steal(
	'jquery/controller',
	'jquery/view/ejs',
    'jquery/controller/view',
    'jquery/dom/route',
    'jquery/lang/observe/delegate',
    'docview/models',
    
    'docview/bootstrap/bootstrap.css',
    './results.css'
)

// View templates
.then(
    './views/results_table.ejs',
    './views/result.ejs'
)

// External JS
.then(
    'docview/datatables/jquery.dataTables.js'
)
.then(
    'docview/datatables/bootstrap-pagination.js'
)

.then(function($) {

    /*
    * Search results for multi-doc and advanced searches
    */
    $.Controller('Docview.Search.Results',
    /* @Static */
    {
    },
    /* @Prototype */
    {
        init: function() {
            // We'll show ourselves during multi or advanced search
            this.element.hide();
            
			/* Modify default datatables class to work with bootstrap better */
			$.extend( $.fn.dataTableExt.oStdClasses, {
				"sSortAsc": "header headerSortDown",
				"sSortDesc": "header headerSortUp",
				"sSortable": "header"
			} );
        },
        '{clientState} search change': function(el, ev, attr, how, newVal, oldVal) {
            var mode = $.route.attr('subcategory');
            if ((mode === "multi" || mode === "advanced") && (how === "set" || how === "add")) {
                this.element.html("Searching...");
                this.element.show();
                Docview.Models.File.findAll(
                    {doc_ids: newVal.ids},
                    this.proxy('showResults'),
                    function() { console.log('Error') }
                );
            }
        },
        showResults: function(docs) {
            this.element.html(this.view('results_table', docs));
            this.element.find('table').dataTable({
                "sDom": "<'row-fluid'<'span6'l><'pull-right'f>r>t<'row-fluid'<'span6'i><'pull-right'p>>",
                "sPaginationType": "bootstrap"
            });
        },
        'td a click': function(el, ev) {
            ev.preventDefault();
            var document = el.closest('tr').model();
            $.route.attrs({category: 'document', id: document.doc_id}, true);
        },
        '{$.route} category change': function(el, ev, attr, how, newVal, oldVal)  {
            if (newVal !== "search") {
                this.element.hide();
            }
        },
        '{$.route} subcategory change': function(el, ev, attr, how, newVal, oldVal)  {
            if (newVal === "multi" || newVal === "advanced") {
                this.element.show();
            }
            else {
                this.element.hide();
            }
        }
    });
});
