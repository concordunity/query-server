steal(
	'jquery/controller',
	'jquery/view/ejs',
    'jquery/controller/view',
    'jquery/dom/route',
    'jquery/lang/observe/delegate',
    'docview/models',
    'docview/bootstrap/bootstrap.css'
)

// View templates
.then(
    './views/search_box.ejs',
    'libs/js/jquery-ui-1.8.19.custom.min.js'
)

// External JS
.then(
    'docview/bootstrap/bootstrap-collapse.js'
)

.then(function($) {

    /*
    * Search box containing three types of search:
    *   - document id
    *   - multiple document ids
    *   - advanced search
    */
    $.Controller('Docview.Search',
    /* @Static */
    {
    },
    /* @Prototype */
    {
        init: function() {
            this.element.html(this.view('search_box', {}));

            // Hide box until route conditions are met
            this.element.hide();
            // Hide search types until route conditions are met
            this.element.find('.single').hide();
            this.element.find('.multi').hide();
            this.element.find('.advanced').hide();
            $('.input-date').datepicker();
        },
        '{$.route} category change': function(el, ev, attr, how, newVal, oldVal)  {
            if (newVal === "search") {
                this.element.show();
            }
            else {
                this.element.hide();
            }
        },
        '{$.route} subcategory change': function(el, ev, attr, how, newVal, oldVal)  {
            if (oldVal !== undefined) {
                this.element.find('.' + oldVal).hide();
            }
            if (newVal !== undefined) {
                this.element.find('.' + newVal).show();
            }
        },
        '.single submit': function(el, ev) {
            ev.preventDefault();
            
            this.removeFormErrors(el);
            
            var docId = $.trim(el.find('.query').val());
            if (this.verify(docId)) {
                // Set clientState's filters and search query
                var filters = [];
                el.find('.filters :checked').each(function() {
                    filters.push($(this).val());
                });
                this.options.clientState.attr('search', {
                    ids: [docId],
                    filters: filters
                });
                
                $.route.attrs({category: 'document', id: docId}, true);
            }
            else {
                this.displayInputError(el, "query", "Document IDs should be 18 digits");
            }
        },
        '.multi submit': function(el, ev) {
            ev.preventDefault();
            
            this.removeFormErrors(el);
            
            // Delimiters: space, comma, newline
            // Anything else would fail verify() later on.
            var query = el.find('.query').val();
            var tokens = query.split(/[\s,]+/);

            var ids = new Array();
            for (var i = 0; i < tokens.length; i++) {
                var docId = $.trim(tokens[i]);
                if (this.verify(docId)) {
                    ids.push(docId);
                }
                else {
                    var errorAt = docId;
                    break;
                }
            }
            
            if (errorAt !== undefined) {
                this.displayTextareaError(el, 'query', 
                    'There was an error starting at: "' + errorAt + '"');
            }
            else {
                // Set clientState's filters and search query
                var filters = [];
                el.find('.filters :checked').each(function() {
                    filters.push($(this).val());
                });
                this.options.clientState.attr('search', {
                    ids: ids,
                    filters: filters
                });
            }
            
            /*
            console.log('[Query]', query);
            console.log('[Tokens]', tokens);
            console.log('[IDs]', ids);
            */
        },
        
        // Filters
        '.select-all click': function(el) {
            this.element.find('.filters .checkbox input').prop("checked", true);
        },
        
        '.deselect-all click': function(el) {
            this.element.find('.filters :checked').prop("checked", false);
        },
        
        // Verifies individual document ids
        verify: function(id) {
            return /^\d{18}$/.test(id);
        },
        
        // Form utility functions
        displayInputError: function(form, name, message) {
            var inputField = form.find('input[name="' + name + '"]');
            inputField.closest('.control-group').addClass('error');
            inputField.after('<span class="help-inline">' + message + '</span>');
        },
        displayTextareaError: function(form, name, message) {
            var inputField = form.find('textarea[name="' + name + '"]');
            inputField.closest('.control-group').addClass('error');
            inputField.after('<span class="help-inline">' + message + '</span>');
        },
        removeFormErrors: function(form) {
            form.find('.error .help-inline').remove();
            form.find('.error').removeClass('error');
        }
    });
});
