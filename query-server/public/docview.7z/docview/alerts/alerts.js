steal(
	'jquery/controller',
	'jquery/view/ejs',
    'jquery/controller/view',
    'jquery/dom/route',
    'jquery/lang/observe/delegate',
    'docview/models',
    
    'docview/bootstrap/bootstrap.css'
)

// View templates
.then(
    './views/alert.ejs'
)

// External JS
.then(
    'docview/bootstrap/bootstrap-alert.js'
)

.then(function($) {

    /*
    * Manage user accounts and roles
    */
    $.Controller('Docview.Alerts',
    /* @Static */
    {
    },
    /* @Prototype */
    {
        init: function() {
            // Since this initializes with nothing in it we don't have to do anything.
        },
        '{clientState} alert change': function(el, ev, attr, how, newVal, oldVal) {
            this.element.html(this.view('alert', newVal));
        }
    });
});
