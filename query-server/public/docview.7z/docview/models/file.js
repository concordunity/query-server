steal('jquery/model', function() {

$.Model('Docview.Models.File',
/* @Static */
{
    models : function(data) {
        console.log(data);
        return this._super(data.results);
    },
    findAll : function(params, success, error) {
        return $.ajax({
            url : '/documents/multi_query',
            type : 'post',
            data : params,
            success : success,
            error : error,
            
            dataType : 'json file.models'
        })
    },
    findOne: function(id, success, error) {
        return $.ajax({
            url: '/docs/' + id,
            type: 'get',
            success: success,
            error: error,
            
            dataType: 'json file.model'
        });
    }
},
/* @Prototype */
{});

});