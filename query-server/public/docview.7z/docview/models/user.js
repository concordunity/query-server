steal('jquery/model', function() {

$.Model('Docview.Models.User',
/* @Static */
{
    models : function(data) {
        // Parse the data into something more usable for our views
        // We want to merge the roles array into the users array
        // Assume that the users array is 1:1 with the roles array in size
        for (var i = 0; i < data.users.length; i++) {
            data.users[i].roles = data.roles[i];
        }
        
        return this._super(data.users);
    },
    findAll : function(params, success, error) {
        return $.ajax({
            url : '/accounts',
            type : 'get',
            data : params,
            success : success,
            error : error,
            
            dataType : 'json user.models'
        })
    },
    findOne: function(id, success, error) {
        return $.ajax({
            url: '/accounts/' + id,
            type: 'get',
            dataType: 'json',
            success: success,
            error: error
        });
    },
    create : function(attrs, success, error) {
        return $.ajax({
            url : '/accounts',
            type : 'POST',
            data : attrs,
            dataType : 'json',
            success : success,
            error : error
        });
    },
    update : function(id, attrs, success, error) {
        return $.ajax({
            url : '/accounts/' + id,
            type : 'PUT',
            data : attrs,
            dataType : 'json',
            success : success,
            error : error
        });
    },
    destroy : function(id, success, error) {
        return $.ajax({
            url : '/accounts/' + id,
            type : 'DELETE',
            dataType : 'json',
            success : success,
            error : error
        });
    },
    getAccessList : function(success, error) {
        return $.ajax({
            url : '/accounts/get_links',
            type : 'GET',
            dataType : 'json',
            success : success,
            error : error
        });
    },
    login : function(params, success, error) {
        return $.ajax({
            url : '/users/login',
            type : 'POST',
            data : params,
            dataType : 'json',
            success : success,
            error : error
        });
    },
    logout : function(success, error) {
        return $.ajax({
            url : '/users/logout',
            type : 'GET',
            dataType : 'json',
            success : success,
            error : error
        });
    }
},
/* @Prototype */
{});

});