// steal model files
steal("jquery/model", './file.js', './user.js', './role.js')