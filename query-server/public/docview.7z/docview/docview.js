﻿steal(
	'./docview.css', 			// application CSS file
	'./models/models.js',		// steals all your models
	//'./fixtures/fixtures.js',	// sets up fixtures for your models
    'jquery',
    'docview/nav',
    'docview/subnav',
    'docview/alerts',
    'docview/search',
    'docview/manage/accounts/users',
    'docview/details',
    'docview/login'
).then(
    'libs/jquery.i18n.min.js'
   ).then( 
	function(){
    
        // Client State
        var state = new $.Observe({
            alert: {
                type: "info",
                heading: "",
                message: ""
            },
            user: {
                username: "",
                fullname: ""
            },
            // Initial access list
            access: {
                search: {
                    single: false,
                    multi: false,
                    advanced: false
                },
                stats: {
                    history: false,
                    stats: false,
                    usage: false
                },
                manage_docs: {
                    inquiries: false,
                    check: false,
                    copy: false,
                    print: false,
                    testify: false
                },
                manage_accounts: {
                    users: false,
                    roles: false
                }
            },
            // Nav menu state
            nav: {
                search: "single",
                stats: "history",
                manage_docs: "inquiries",
                manage_accounts: "users"
            },
            // Search term state
            search: {
                ids: [],
                filters: []
            },
            // Document viewer state
            document: {
                pages: [],
                directory: ""
            }
        });
        
        $('#alerts').docview_alerts({clientState: state});
        $('#login').docview_login({clientState: state});
        
    i18n_dict = {
	'search_by_id' : '按单证查询',
       'menu_search' : '单证查阅',
       'menu_report' : '查阅管理',
       'menu_operation' : '单证操作',
       'menu_accounts' : '权限管理',
       'menu_logout' : '退出',
       'menu_profile' : '设置',
       'subnav_single_document' : '按报关单号单票查阅',
       'subnav_multi_document' : '按报关单号批量查阅',
       'subnav_advanced_search' : '随机抽样查阅',
   };
	    $.i18n.setDictionary(i18n_dict);
        // The method below doesn't work because we don't have user info from the access list.
        // Try to get the access list
        // If this fails, then we know we're not logged in and we need to log in
        // 401 Unauthorized
        // {"error":"You need to sign in or sign up before continuing."}
	}
    
)
