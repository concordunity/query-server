steal(
	'jquery/controller',
	'jquery/view/ejs',
    'jquery/controller/view',
    'jquery/dom/route',
    'jquery/lang/observe/delegate',
    'docview/models',
    
    'docview/bootstrap/bootstrap.css'
)

// View templates
.then(
    './views/init.ejs',
    './views/users_table.ejs',
    './views/user_row.ejs',
    './views/edit_user.ejs',
    './views/new_user.ejs'
)

// External JS
.then(
    'docview/bootstrap/bootstrap-button.js',
    'docview/bootstrap/bootstrap-collapse.js',
    'docview/bootstrap/bootstrap-alert.js'
)

.then(function($) {

    /*
    * Manage user accounts and roles
    */
    $.Controller('Docview.Manage.Accounts.Users',
    /* @Static */
    {
    },
    /* @Prototype */
    {
        init: function() {
            this.element.html(this.view('init', {}));
            
            // By default we're hidden until the route conditions are met
            this.element.hide();
        },

        // Showing/hiding of this controller
        '{$.route} category change': function(el, ev, attr, how, newVal, oldVal)  {
            // Category and subcategory are edited in a 2 stage process, and if
            // order can't be guaranteed, then it's possible that the 
            // subcategory show() comes before this hide(), which results in 
            // unexpected behavior.
            
            /*if (newVal !== "manage_accounts") {
                this.element.hide();
            }*/
        },
        '{$.route} subcategory change': function(el, ev, attr, how, newVal, oldVal) {
            // console.log(attr, how, newVal, oldVal);
            if (how === "add" || how === "set") {
                if (newVal === "users") {
                    this.reload();
                    this.element.show();
                }
                else {
                    this.element.hide();
                }
            }
        },
        
        // Data queries
        reload: function() {
            Docview.Models.User.findAll({}, this.proxy('listUsers'), this.proxy('failure'));
            Docview.Models.Role.findAll({}, this.proxy('storeRoles'), this.proxy('failure'));
        },
        listUsers: function(users) {
            this.element.find('.user-list').html(this.view('users_table', users));
        },
        failure: function(error) {
            console.log(error);
        },
        storeRoles: function(roles) {
            // Keep a reference to the list of available roles.
            // This is useful when showing a list of available roles
            // that we can assign to a user.
            this.roles = roles;
            console.log(this.roles);
        },
        
        // Creating a user
        '#new-user-btn click': function() {
            // Load up the creation form
            $('#new-user').html(this.view('new_user', {roles: [this.roles]}));
        },
        '#new-user-form submit': function(el, ev) {
            ev.preventDefault();
            var username = el.find('input[name="username"]').val();
            var fullname = el.find('input[name="fullname"]').val();
            var roles = el.find('select').val();
            var email = el.find('input[name="email"]').val();
            var organizations = el.find('input[name="organizations"]').val();
            var password = el.find('input[name="password"]').val();
            var confirmation = el.find('input[name="password-confirm"]').val();

            // Clear any previous error messages in the form
            this.removeFormErrors(el);
            
            // Scan for empty fields (jsmvc can actually do this in the model layer I believe)
            var error = false;
            if (username === "") {
                this.displayFormError(el, "username", "Please enter a username");
                error = true;
            }
            if (fullname === "") {
                this.displayFormError(el, "fullname", "Please enter a name");
                error = true;
            }
            if (password === "") {
                this.displayFormError(el, "password", "Please enter a password");
                error = true;
            }
            
            // Check that confirmation matches
            if (password !== confirmation) {
                this.displayFormError(el, "password-confirm", "This does not match your password");
                error = true;
            }
            
            if (!error) {
                /*var user = new Docview.Models.User({
                    username: username,
                    fullname: fullname,
                    roles: [roles],
                    orgs: organizations,
                    password: password,
                    email: email
                });*/
                var user = new Docview.Models.User({
                    role: roles,
                    user: {
                        username: username,
                        fullname: fullname,
                        orgs: organizations,
                        password: password,
                        email: email
                    }
                });
                
                // Lock the save and cancel buttons
                el.find('.btn-primary').button('loading');
                el.find('.cancel-create').button('loading');
                
                user.save(this.proxy('addUserRow'));
            }
        },
        '.cancel-create click': function() {
            $('#new-user').collapse('hide');
        },
        addUserRow: function(user, response) {
            console.log('[User]', user);
            console.log('[Response]', response);
            if (user.status === 200) {
                // Remove a few unnecessary fields in user
                delete user.status;
                delete user.password;
                delete user.user;
                
                console.log(user, response);
                
                // Copy over the user id since we don't have that
                user.id = response.user.id;
                
                var newRow = $(this.view('user_row', user)).css('display', 'none');
                this.element.find('tbody').prepend(newRow);
                newRow.fadeIn('slow');
            }
            else {
                // Throw an alert
                this.options.clientState.attr('alert', {
                    type: "error",
                    heading: "Error!",
                    message: "There was an error while trying to create this user."
                });
            }
            $('#new-user-form .btn-primary').button('reset');
            $('#new-user-form .cancel-create').button('reset');
        },
        
        // Editing a user
        '.edit-user click': function(el, ev) {
            // In place edit form
            var userRow = el.closest('tr');
            userRow.hide();
            userRow.after(this.view('edit_user', 
                {roles: [this.roles], user: userRow.model()})); 
        },
        '.edit-user-form submit': function(el, ev) {
            ev.preventDefault();
            
            // Clear any previous error messages in the form
            this.removeFormErrors(el);
            
            var password = el.find('input[name="password"]').val();
            var confirmation = el.find('input[name="password-confirm"]').val();
            if (password !== confirmation) {
                this.displayFormError(el, "password-confirm", "Please confirm your new password");
            }
            else {
                // Update model entry
                // The user model row is a hidden entry right above the edit row
                var user = el.closest('tr').prev().model();
                user.attr('roles', el.find('select').val());
                if (password !== undefined) {
                    user.attr('password', password);
                }
                user.attr('username', el.find('input[name="username"]').val());
                user.attr('orgs', el.find('input[name="organizations"]').val());
                user.attr('email', el.find('input[name="email"]').val());
                
                // Lock the save and cancel buttons
                el.find('.btn-primary').button('loading');
                el.find('.cancel-edit').button('loading');
                
                // Save
                user.save(this.proxy('updateUserRow'));
            }
        },
        '.cancel-edit click': function(el, ev) {
            var editRow = el.closest('tr');
            editRow.prev().show();
            editRow.remove();
        },
        updateUserRow: function(user) {
            var oldRow = user.elements(this.element);
            // Close edit box 
            oldRow.next().remove();
            
            var newRow = $(this.view('user_row', user)).css('display', 'none');
            oldRow.replaceWith(newRow);
            newRow.fadeIn('slow');
        },
        
        // Deleting a user
        '.delete-user click': function(el, ev) {
            el.button('loading');
            if (confirm("Are you sure you want to delete this user? This action is permanent and cannot be reversed!")){
                el.closest('.user').model().destroy();
            }
            else {
                el.button('reset');
            }
        },
        '{Docview.Models.User} destroyed': function(User, ev, user) {
            user.elements(this.element).remove();
        },
        
        // Form utility functions
        displayFormError: function(form, name, message) {
            var inputField = form.find('input[name="' + name + '"]');
            inputField.closest('.control-group').addClass('error');
            inputField.after('<span class="help-inline">' + message + '</span>');
        },
        removeFormErrors: function(form) {
            form.find('.error > .help-inline').remove();
            form.find('.error').removeClass('error');
        }
    });
});
