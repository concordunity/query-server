class DocumentHistoriesController < ApplicationController
  # GET /document_histories
  # GET /document_histories.json
  def index
    @document_histories = DocumentHistory.all

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @document_histories }
    end
  end

  # GET /document_histories/1
  # GET /document_histories/1.json
  def show
    @document_history = DocumentHistory.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @document_history }
    end
  end

  # GET /document_histories/new
  # GET /document_histories/new.json
  def new
    @document_history = DocumentHistory.new

    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @document_history }
    end
  end

  # GET /document_histories/1/edit
  def edit
    @document_history = DocumentHistory.find(params[:id])
  end

  def query
    @document_histories = DocumentHistory.where(:doc_id => params[:doc_id])
    render :json => @document_histories, :status => 200
  end

  def dh_special
    inquired_docs = Document.where('inquired=true OR checkedout =  true')
    render :json => inquired_docs, :status => 200
  end


  def dh_report
    # return 
    docs_stats = Document.group("org").count
    query_stats = QueryHistory.group("org").count
    stats = {}
    v = Document.count
    v2 = QueryHistory.count
    p = 0
    if v.to_i
      p = v2.to_f / v.to_f * 100
    end
    stats[:total]  =  { :docs => v, :query => v2, :percentage => p }

    docs_stats.each do |k,v|
      p = 0
      v2 = '0'
      if query_stats.has_key?(k)
        v2 = query_stats[k]
        p = v2.to_f / v.to_f * 100
      end
      stats[k] = { :docs => v, :query => v2, :percentage => p }
    end
    
    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: stats }
    end
  end

  # POST /document_histories
  # POST /document_histories.json
  def create
    @document_history = DocumentHistory.new(params[:document_history])

    respond_to do |format|
      if @document_history.save
        format.html { redirect_to @document_history, notice: 'Document history was successfully created' }
        format.json { render json: @document_history, status: :created, location: @document_history }
      else
        format.html { render action: "new" }
        format.json { render json: @document_history.errors, status: :unprocessable_entity }
      end
    end
  end

  # PUT /document_histories/1
  # PUT /document_histories/1.json
  def update
    @document_history = DocumentHistory.find(params[:id])

    respond_to do |format|
      if @document_history.update_attributes(params[:document_history])
        format.html { redirect_to @document_history, notice: 'Document history was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: "edit" }
        format.json { render json: @document_history.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /document_histories/1
  # DELETE /document_histories/1.json
  def destroy
    @document_history = DocumentHistory.find(params[:id])
    @document_history.destroy

    respond_to do |format|
      format.html { redirect_to document_histories_url }
      format.json { head :no_content }
    end
  end
end
